<html>
<head>
	<title> Erro - Tarefa6 </title>
	<meta charset="utf-8">
</head>
<body>
	<h1> NÃO FUNCIONOU !!!!! </h1>
	<h2> Acho que alguma coisa deu errado !!!!</h2>
	<br><br><input type="button" onclick="window.location='Index_Tarefa6.php'" value="Voltar">
</body>
</html>