<html> 

	<head>
	
		<title> Ínicio </title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="cadastro.css">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Rock+Salt&display=swap" rel="stylesheet">
		
	</head>
	
	<body>
	
		<header class="cabecalho">
		
			<h1 class="logo">
				<a href="AbaInicial.html" title="Skate Shop">Skate Shop</a>
			</h1>
		
			<ul><a href="cadastro.html">Cadastro</a></ul>
			<ul><a href="1234">Sobre Nós</a></ul>
            <ul><a href="1234">Produtos</a></ul>
			<ul><a href="1234">Monte seu Skate</a></ul>
		
		</header> 
		
		<?php
		
			include_once("conexao.php");
	
			$nome=$_POST['nome'];
			$senha=$_POST['senha'];
			$email=$_POST['email'];
			
			$sqlselect= "SELECT * FROM login WHERE email = '$email'";
			$resultadoselect = @mysqli_query($conect,$sqlselect);
		
			if (@mysqli_num_rows($resultadoselect)==0){
				$sql = "insert into login (nome,email,senha) values ('$nome','$email','$senha')";
				$resultado = @mysqli_query($conect,$sql);
				if (!$resultado){
					die ('Query Inválida: ' . @mysqli_error($conect));
					exit;
				}else{
					mysqli_close($conect);
				}
			}
			else{
				echo "Cadastrado com sucesso!";

			}
	
		?>
	</body>
	
</html> 