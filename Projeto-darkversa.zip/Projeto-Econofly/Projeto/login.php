<!DOCTYPE html>
<html>

		<head>
	
		<title> Ínicio </title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="cadastro.css">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Rock+Salt&display=swap" rel="stylesheet">
		
		</head>
		
	<body>
		<?php
	
			if(!empty($_POST['email']) and !empty($_POST['senha'])) {
		
				include_once("conexao.php");
				$email = $_POST['email'];
				$senha = $_POST['senha'];
		

		
				$sql = ("SELECT * FROM login WHERE email = '$email' AND senha='$senha'");
				$resultado = @mysqli_query($conect,$sql);
		
				if (@mysqli_num_rows($resultado)==0){
			
					echo "Senha ou Usuário incorretos! </br> Caso o erro persista faça um novo cadastro"."</br>";
					echo "<a href='login.html'>Voltar</a><br>";
					exit;
			
				}
				else {

					echo "<h3> Logado com sucesso!: </h3>"."</br>";
				}
		
		}	
		?>
	</body>
</html>